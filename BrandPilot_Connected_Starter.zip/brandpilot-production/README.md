# BrandPilot — Social Network

BrandPilot is a mobile-first creative social network built with React, TypeScript, Vite and Supabase. It retains the navy/blue/cyan/yellow/lime/pink/purple palette and the animated B launch screen.

## Included in this project

- Email/password sign-up, sign-in, password reset, and Google OAuth code path.
- Responsive home feed with posts, image/video media, timestamps, likes, comments and share links.
- Profile editing, avatar URL support and profile-photo uploads.
- Explore creators, follow/unfollow, following feed, saved posts and light/dark themes.
- Notification inbox backed by database notifications generated for likes, comments and follows.
- Creator analytics totals for posts, likes, comments and recorded post views.
- Supabase Realtime refresh for new posts and notifications.
- PWA manifest and service worker for installability in Chrome after HTTPS deployment.
- Capacitor Android project configuration to support an Android build on a machine with the Android SDK installed.

## Supabase connection

This source is configured to use the existing BrandPilot Supabase project:

- Project URL: `https://tyuzmobmenfcknsetnls.supabase.co`
- Browser key: Supabase publishable key (safe for browser use when Row Level Security is correctly enabled).

The database foundation has already been provisioned in the connected project. **Do not rerun the historical SQL files in `supabase/migrations/001_initial_schema.sql` through `003_video_media.sql` against that project**; those files came from an earlier starter version and do not match the current schema. The active project has `profiles`, `posts`, `comments`, `likes`, `follows`, `notifications`, `post_views`, and `saved_posts`, with RLS enabled.

Never put a Supabase service-role/secret key or an OpenAI secret key in frontend code.

## Run locally

Install Node.js 20+ and npm, then:

```sh
npm install
npm run dev
```

Vite prints a local URL. Open it in Chrome. The Supabase project URL and publishable key are in `.env.example`; copy that file to `.env` if needed. Email sign-up may require email confirmation according to the Supabase Auth settings.

## Google sign-in

The application includes Google OAuth initiation, but Google sign-in will work only after a project owner configures Google under Supabase Dashboard → Authentication → Providers and adds the app's exact callback/redirect URLs. OAuth client credentials are not included in this source package.

## Deploy the web app

Run:

```sh
npm run build
```

Deploy the generated `dist/` directory to an HTTPS static host such as Netlify or Vercel. Then add the deployed origin to Supabase Authentication → URL Configuration (Site URL and allowed redirect URLs). This workspace did not complete a live hosting deployment; no public production URL is claimed here.

## Install from Chrome (PWA)

After the web app is deployed over HTTPS, open its URL in Chrome on Android, open the browser menu, and choose **Install app** or **Add to Home screen**. This installs the PWA; it is not the same as a standalone APK file.

## Build an Android APK

This project includes Capacitor configuration, but an APK has **not** been built or signed in this workspace. On a machine with Node.js and Android Studio/Android SDK installed:

```sh
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```

Build the APK from Android Studio. A release APK should be signed with credentials controlled by the app owner. The current workspace has Java but no Android SDK/Gradle toolchain, so it cannot produce a tested APK here.

## Not yet connected

- AI answers require a secure server-side AI provider integration and an API secret stored as a server secret. No AI key is configured, so the app must not claim AI responses are live.
- Real push notifications require web-push/FCM setup; the current notification inbox is database-backed, not native push.
- Google OAuth requires provider configuration by the project owner.
- A public production deployment and APK build/signing are still pending.

## Security notes

RLS is enabled on all exposed BrandPilot data tables. Storage uploads are restricted to a user-owned folder path. Public post/avatar media buckets are intended for public-facing content only; do not upload private files. Before a public launch, test with multiple accounts and configure abuse reporting, moderation, rate limits, privacy terms, backups and production auth redirects.
