-- BrandPilot production foundation: profiles, posts, likes, comments, saved posts, projects.
-- Run in the Supabase SQL Editor as the project owner. RLS is enabled on every user table.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null check (username ~ '^[a-zA-Z0-9_]{3,24}$'),
  display_name text not null default 'BrandPilot member' check (char_length(display_name) between 1 and 60),
  bio text not null default '' check (char_length(bio) <= 280),
  avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists public.posts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 3000),
  image_url text,
  visibility text not null default 'public' check (visibility in ('public','followers')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists posts_created_at_idx on public.posts(created_at desc);
create index if not exists posts_user_created_idx on public.posts(user_id, created_at desc);
create table if not exists public.likes (
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(post_id,user_id)
);
create table if not exists public.comments (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 1200),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists comments_post_created_idx on public.comments(post_id,created_at);
create table if not exists public.saved_posts (
  post_id uuid not null references public.posts(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(post_id,user_id)
);
create table if not exists public.projects (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 120),
  description text not null default '' check (char_length(description) <= 3000),
  status text not null default 'active' check (status in ('active','paused','completed')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.set_updated_at() returns trigger language plpgsql as $$ begin new.updated_at = now(); return new; end; $$;
drop trigger if exists profiles_updated_at on public.profiles;
create trigger profiles_updated_at before update on public.profiles for each row execute function public.set_updated_at();
drop trigger if exists posts_updated_at on public.posts;
create trigger posts_updated_at before update on public.posts for each row execute function public.set_updated_at();
drop trigger if exists comments_updated_at on public.comments;
create trigger comments_updated_at before update on public.comments for each row execute function public.set_updated_at();
drop trigger if exists projects_updated_at on public.projects;
create trigger projects_updated_at before update on public.projects for each row execute function public.set_updated_at();

alter table public.profiles enable row level security;
alter table public.posts enable row level security;
alter table public.likes enable row level security;
alter table public.comments enable row level security;
alter table public.saved_posts enable row level security;
alter table public.projects enable row level security;

-- Profiles are publicly readable for community attribution; members may edit only their own.
drop policy if exists "profiles readable" on public.profiles;
create policy "profiles readable" on public.profiles for select using (true);
drop policy if exists "profile insert own" on public.profiles;
create policy "profile insert own" on public.profiles for insert to authenticated with check (auth.uid() = id);
drop policy if exists "profile update own" on public.profiles;
create policy "profile update own" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

-- Public feed is readable to signed-in users; only authors can create/update/delete their own posts.
drop policy if exists "signed in read public posts" on public.posts;
create policy "signed in read public posts" on public.posts for select to authenticated using (visibility = 'public' or user_id = auth.uid());
drop policy if exists "create own posts" on public.posts;
create policy "create own posts" on public.posts for insert to authenticated with check (user_id = auth.uid());
drop policy if exists "update own posts" on public.posts;
create policy "update own posts" on public.posts for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
drop policy if exists "delete own posts" on public.posts;
create policy "delete own posts" on public.posts for delete to authenticated using (user_id = auth.uid());

-- Likes: signed-in members can read likes, and can only add/remove their own.
drop policy if exists "likes readable" on public.likes;
create policy "likes readable" on public.likes for select to authenticated using (true);
drop policy if exists "like as self" on public.likes;
create policy "like as self" on public.likes for insert to authenticated with check (user_id = auth.uid());
drop policy if exists "unlike as self" on public.likes;
create policy "unlike as self" on public.likes for delete to authenticated using (user_id = auth.uid());

-- Comments: signed-in members can read, author can create/update/delete their own comments.
drop policy if exists "comments readable" on public.comments;
create policy "comments readable" on public.comments for select to authenticated using (true);
drop policy if exists "create own comments" on public.comments;
create policy "create own comments" on public.comments for insert to authenticated with check (user_id = auth.uid());
drop policy if exists "update own comments" on public.comments;
create policy "update own comments" on public.comments for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
drop policy if exists "delete own comments" on public.comments;
create policy "delete own comments" on public.comments for delete to authenticated using (user_id = auth.uid());

-- Saved posts are private to the member who saved them.
drop policy if exists "read own saved posts" on public.saved_posts;
create policy "read own saved posts" on public.saved_posts for select to authenticated using (user_id = auth.uid());
drop policy if exists "save as self" on public.saved_posts;
create policy "save as self" on public.saved_posts for insert to authenticated with check (user_id = auth.uid());
drop policy if exists "unsave as self" on public.saved_posts;
create policy "unsave as self" on public.saved_posts for delete to authenticated using (user_id = auth.uid());

-- Projects are private by default and only visible to their owner.
drop policy if exists "read own projects" on public.projects;
create policy "read own projects" on public.projects for select to authenticated using (user_id = auth.uid());
drop policy if exists "create own projects" on public.projects;
create policy "create own projects" on public.projects for insert to authenticated with check (user_id = auth.uid());
drop policy if exists "update own projects" on public.projects;
create policy "update own projects" on public.projects for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
drop policy if exists "delete own projects" on public.projects;
create policy "delete own projects" on public.projects for delete to authenticated using (user_id = auth.uid());

-- Realtime: enable feed-related tables in the publication if not already present.
do $$ begin
  if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='posts') then alter publication supabase_realtime add table public.posts; end if;
  if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='likes') then alter publication supabase_realtime add table public.likes; end if;
  if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='comments') then alter publication supabase_realtime add table public.comments; end if;
end $$;
