-- BrandPilot social features: notifications, follows, storage, and secure triggers.
create table if not exists public.follows (
  follower_id uuid not null references public.profiles(id) on delete cascade,
  following_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (follower_id, following_id),
  constraint follows_no_self check (follower_id <> following_id)
);
create index if not exists follows_following_idx on public.follows(following_id);
alter table public.follows enable row level security;
drop policy if exists "follows readable by members" on public.follows;
create policy "follows readable by members" on public.follows for select to authenticated using (true);
drop policy if exists "follow as self" on public.follows;
create policy "follow as self" on public.follows for insert to authenticated with check (follower_id = auth.uid());
drop policy if exists "unfollow as self" on public.follows;
create policy "unfollow as self" on public.follows for delete to authenticated using (follower_id = auth.uid());

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  recipient_id uuid not null references public.profiles(id) on delete cascade,
  actor_id uuid references public.profiles(id) on delete set null,
  kind text not null check (kind in ('like','comment','follow')),
  post_id uuid references public.posts(id) on delete cascade,
  comment_id uuid references public.comments(id) on delete cascade,
  read_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists notifications_recipient_created_idx on public.notifications(recipient_id, created_at desc);
alter table public.notifications enable row level security;
drop policy if exists "read own notifications" on public.notifications;
create policy "read own notifications" on public.notifications for select to authenticated using (recipient_id = auth.uid());
drop policy if exists "mark own notifications read" on public.notifications;
create policy "mark own notifications read" on public.notifications for update to authenticated using (recipient_id = auth.uid()) with check (recipient_id = auth.uid());

create or replace function public.notify_post_like() returns trigger language plpgsql security definer set search_path = public as $$
declare owner_id uuid; begin select user_id into owner_id from public.posts where id = new.post_id; if owner_id is not null and owner_id <> new.user_id then insert into public.notifications(recipient_id,actor_id,kind,post_id) values(owner_id,new.user_id,'like',new.post_id); end if; return new; end; $$;
drop trigger if exists likes_notify_owner on public.likes;
create trigger likes_notify_owner after insert on public.likes for each row execute function public.notify_post_like();
create or replace function public.notify_post_comment() returns trigger language plpgsql security definer set search_path = public as $$
declare owner_id uuid; begin select user_id into owner_id from public.posts where id = new.post_id; if owner_id is not null and owner_id <> new.user_id then insert into public.notifications(recipient_id,actor_id,kind,post_id,comment_id) values(owner_id,new.user_id,'comment',new.post_id,new.id); end if; return new; end; $$;
drop trigger if exists comments_notify_owner on public.comments;
create trigger comments_notify_owner after insert on public.comments for each row execute function public.notify_post_comment();
create or replace function public.notify_followed() returns trigger language plpgsql security definer set search_path = public as $$ begin insert into public.notifications(recipient_id,actor_id,kind) values(new.following_id,new.follower_id,'follow'); return new; end; $$;
drop trigger if exists follows_notify_owner on public.follows;
create trigger follows_notify_owner after insert on public.follows for each row execute function public.notify_followed();

-- Public image bucket; upload paths are scoped to the authenticated user's UUID.
insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('post-media','post-media',true,8388608,array['image/jpeg','image/png','image/webp','image/gif'])
on conflict (id) do update set public=true,file_size_limit=8388608,allowed_mime_types=array['image/jpeg','image/png','image/webp','image/gif'];
drop policy if exists "members upload own post media" on storage.objects;
create policy "members upload own post media" on storage.objects for insert to authenticated with check (bucket_id='post-media' and (storage.foldername(name))[1]=auth.uid()::text);
drop policy if exists "public read post media" on storage.objects;
create policy "public read post media" on storage.objects for select using (bucket_id='post-media');
drop policy if exists "members delete own post media" on storage.objects;
create policy "members delete own post media" on storage.objects for delete to authenticated using (bucket_id='post-media' and (storage.foldername(name))[1]=auth.uid()::text);

do $$ begin
  if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='notifications') then alter publication supabase_realtime add table public.notifications; end if;
  if not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='follows') then alter publication supabase_realtime add table public.follows; end if;
end $$;
