-- Run after 001 and 002. Adds video metadata and expands media storage support.
alter table public.posts add column if not exists media_type text check (media_type in ('image','video') or media_type is null);
update storage.buckets set file_size_limit = 52428800, allowed_mime_types = array['image/jpeg','image/png','image/webp','image/gif','video/mp4','video/webm','video/quicktime'] where id='post-media';
